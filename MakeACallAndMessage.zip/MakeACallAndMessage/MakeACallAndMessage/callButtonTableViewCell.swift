//
//  callButtonTableViewCell.swift
//  MakeACallAndMessage
//
//  Created by kireeti on 27/08/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import UIKit
protocol MyCellDelegate: AnyObject {
    func btnCloseTapped(cell: callButtonTableViewCell)
}
class callButtonTableViewCell: UITableViewCell {
 weak var delegate: MyCellDelegate?
    
    
    @IBOutlet var NumberLbl: UILabel!
    @IBOutlet var callButton: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    @IBAction func cellButtonAction(_ sender: UIButton) {
        delegate?.btnCloseTapped(cell: self)
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
