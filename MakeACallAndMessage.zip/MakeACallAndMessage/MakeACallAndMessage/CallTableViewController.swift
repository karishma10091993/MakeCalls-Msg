//
//  CallTableViewController.swift
//  MakeACallAndMessage
//
//  Created by kireeti on 27/08/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import UIKit

class CallTableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, MyCellDelegate {
   
    

   var numberArray = ["9511391761","9512391761","9211391761","8511391761","8511391761","7511391761","9711391761","8511391761","9963982896"]
    
    
    @IBOutlet var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numberArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! callButtonTableViewCell
        cell.NumberLbl.text = numberArray[indexPath.row]
        cell.delegate = self
        return cell
    }
    func btnCloseTapped(cell: callButtonTableViewCell) {
        let num = cell.NumberLbl.text
        
//        let a:Int? = Int(cell.NumberLbl.text!)
        print(num!)
        
        guard let number = URL(string: num!) else { return }
        print(number)
        if #available(iOS 11.2, *) {
            UIApplication.shared.open(number)
        } else {
            // Fallback on earlier versions
            UIApplication.shared.openURL(number)
        }
        
        
//        if let url = URL(string: "tel://\(a)"), UIApplication.shared.canOpenURL(url) {
//            if #available(iOS 10, *) {
//                UIApplication.shared.open(url)
//            } else {
//                UIApplication.shared.openURL(url)
//            }
//        }
    }
    

}
