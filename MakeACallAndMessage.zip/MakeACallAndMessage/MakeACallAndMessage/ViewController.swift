//
//  ViewController.swift
//  MakeACallAndMessage
//
//  Created by kireeti on 20/08/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import UIKit
import MessageUI
class ViewController: UIViewController,MFMessageComposeViewControllerDelegate  {

    @IBOutlet weak var ttVSms: UITextView!
    @IBOutlet weak var txtphoneNumber: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        print("viewDidLoad")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func btnSMS_Clicked(sender: AnyObject) {
        if (MFMessageComposeViewController.canSendText()){
            let controller = MFMessageComposeViewController()
            controller.body = self.ttVSms.text
            controller.recipients = [self.txtphoneNumber.text!]
            controller.messageComposeDelegate = self as! MFMessageComposeViewControllerDelegate
            self.present(controller, animated: true, completion: nil)
        }
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btncall_Clicked(sender: AnyObject) {
        
        let phoneNumber:String = "tel:" + self.txtphoneNumber.text!
        UIApplication.shared.openURL(URL(string: phoneNumber)!)
        
    }


}

